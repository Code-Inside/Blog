﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SurfaceTwitter.Model
{
    public class User
    {
        public string Name { get; set; }
        public string PictureUrl { get; set; }
    }
}
