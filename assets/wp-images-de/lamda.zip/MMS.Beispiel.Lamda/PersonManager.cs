﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MMS.Beispiel.Lamda
{
    class PersonManager
    {
        public static List<Person> GetRandomData(int count)
        {
            String[] Firstnames = { "Jill", "Jeff", "Liza", "Robert", "Oliver", "Jane", "Tom", "James", "Maria", "Ken" };
            String[] Surnames = { "Miller", "Foster", "Lee", "Gale", "Freud", "Parker", "Gates", "Jobs", "Ford", "Bernanke" };


            List<Person> ResultSet = new List<Person>();
            Random RandomNumber = new Random();

            for (int i = 0; i < count; i++)
            {
                ResultSet.Add(new Person(Surnames[RandomNumber.Next(9)], Firstnames[RandomNumber.Next(9)], RandomNumber.Next(18,30), RandomNumber.Next(999999)));
            }

            return ResultSet;
        }
    }
}
