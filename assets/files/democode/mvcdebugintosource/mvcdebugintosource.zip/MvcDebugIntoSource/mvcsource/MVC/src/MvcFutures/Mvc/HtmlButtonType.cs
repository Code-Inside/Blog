﻿namespace Microsoft.Web.Mvc {
    public enum HtmlButtonType {
        Button,
        Submit,
        Reset,
    }
}
