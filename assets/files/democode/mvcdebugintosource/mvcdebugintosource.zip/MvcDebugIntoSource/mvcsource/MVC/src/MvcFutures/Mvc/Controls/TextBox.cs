﻿namespace Microsoft.Web.Mvc.Controls {

    public class TextBox : MvcInputControl {
        public TextBox() :
            base("text") {
        }
    }
}
