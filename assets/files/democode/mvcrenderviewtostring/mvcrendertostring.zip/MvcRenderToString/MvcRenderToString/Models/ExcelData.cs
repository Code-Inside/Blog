﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcRenderToString.Models
{
    public class ExcelData
    {
        public string Foobar { get; set; }
    }
}
