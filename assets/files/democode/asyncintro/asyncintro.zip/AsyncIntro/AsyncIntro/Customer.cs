using System;

namespace AsyncIntro
{
    public class Customer
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public Guid Id { get; set; }
    }
}