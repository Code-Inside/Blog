﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCNestedMasterPagesDynamicContent.Models.ViewData
{
    public class SiteMasterViewData
    {
        public string Title { get; set; }
    }
}
