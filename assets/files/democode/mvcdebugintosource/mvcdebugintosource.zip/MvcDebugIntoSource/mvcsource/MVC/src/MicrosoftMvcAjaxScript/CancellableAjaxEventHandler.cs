﻿namespace Sys.Mvc {
    public delegate bool CancellableAjaxEventHandler(AjaxContext context);
}