namespace MvcLocalization.WebApp.Infrastructure
{
    public enum LanguageKey
    {
        De = 1031,
        En = 1033
    }
}