﻿namespace CastleWindsorFindAllImplementations.Commands
{
    public interface ICommand
    {
        void Execute();
    }
}