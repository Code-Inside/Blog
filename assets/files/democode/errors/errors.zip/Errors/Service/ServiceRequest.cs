﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Service
{
    public class ServiceRequest<T>
    {
        public T Value { get; set; }
    }
}
