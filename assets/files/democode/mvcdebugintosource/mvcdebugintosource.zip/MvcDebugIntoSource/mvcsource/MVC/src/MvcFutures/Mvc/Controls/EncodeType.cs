﻿namespace Microsoft.Web.Mvc.Controls {

    public enum EncodeType {
        Html,
        HtmlAttribute,
        None,
    }
}
