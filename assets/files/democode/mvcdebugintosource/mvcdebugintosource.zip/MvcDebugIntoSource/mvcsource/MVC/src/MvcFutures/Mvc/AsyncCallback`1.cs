﻿namespace Microsoft.Web.Mvc {
    using System;

    public delegate TResult AsyncCallback<TResult>(IAsyncResult ar);
    
}
