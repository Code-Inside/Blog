﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace WebHistory.Model
{
    public class ArchiveWebsite
    {
        public DateTime Date { get; set; }
        public string ArchiveUrl { get; set; } 
    }
}
