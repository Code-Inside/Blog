﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCNestedMasterPagesDynamicContent.Models.ViewData
{
    public class ViewDataBase
    {
        public SiteMasterViewData SiteMasterViewData { get; set; }
    }
}
