﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MMS.Beispiel.Lamda
{
    class Person
    {
        public Person(string surname, string firstname,int age , int personalId)
        {
            Surname = surname;
            Firstname = firstname;
            PersonalId = personalId;
            Age = age;
        }

        public string Surname { get; set; }
        public string Firstname { get; set; }
        public int PersonalId { get; set; }
        public int Age { get; set; }
    }
}
