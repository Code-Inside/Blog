﻿namespace Microsoft.Web.Mvc {
    using System;

    public delegate IAsyncResult BeginInvokeCallback(AsyncCallback callback, object state);
    
}
