﻿namespace Sys.Mvc {
    public delegate void AjaxEventHandler(AjaxContext context);
}
