using System;
using System.Collections.Generic;
using System.Text;

namespace UsingInterfaces.Nature
{
    public interface IMovable
    {
        void Move();
    }
}
