﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("AssemblyInfoKeepItDry.Bla")]
[assembly: AssemblyDescription("")]
[assembly: Guid("ba581b38-ab40-4d44-9f2b-e816cc2091df")]
