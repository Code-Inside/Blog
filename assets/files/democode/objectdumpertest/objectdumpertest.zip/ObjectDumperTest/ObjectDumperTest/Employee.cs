using System;

namespace ObjectDumperTest
{
    public class Employee : Person
    {
        public DateTime HiredOn { get; set; }
    }
}