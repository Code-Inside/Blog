﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("AssemblyInfoKeepItDry.Service")]
[assembly: AssemblyDescription("")]
[assembly: Guid("ee7c20b8-30dc-4143-bf9c-59f2d53acd85")]
