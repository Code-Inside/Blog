﻿namespace System.Web.Mvc {
    public enum FormMethod {
        Get,
        Post
    }
}