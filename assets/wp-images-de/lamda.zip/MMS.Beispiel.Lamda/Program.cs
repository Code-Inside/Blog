﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//info: http://msdn.microsoft.com/de-de/library/bb882642.aspx

namespace MMS.Beispiel.Lamda
{
    class Program
    {
        static void Main(string[] args)
        {            
            List<Person> Employees = PersonManager.GetRandomData(19);            
            
            Console.WriteLine("shows all employees");          
            ViewPersonList(Employees);
            
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("shows all Liza's (Where)");           
            ViewPersonList(Employees.Where(x => x.Firstname == "Liza").ToList());

            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("order's all employees by PersonalId (OrderBy)");            
            ViewPersonList(Employees.OrderBy(x => x.PersonalId).ToList());

            int[] test = new int[100];

            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("order's all employees by surename and firstname (OrderBy)");
            ViewPersonList(Employees.OrderBy(x => x.Surname).ThenBy(x => x.Firstname).ToList());

            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("employee statistics (Min,Max,Sum,Average)");
            Console.WriteLine("the youngest employee is:\t" + Employees.Min(x => x.Age) + "\tyears old");
            Console.WriteLine("the oldest employee is:\t\t" + Employees.Max(x => x.Age) + "\tyears old");
            Console.WriteLine("all employee's are:\t\t" + Employees.Sum(x => x.Age) + "\tyears old");
            Console.WriteLine("the average age is:\t\t" + Employees.Average(x => x.Age));

            
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("groups's all employees by age(GroupBy)");
            Console.WriteLine("order's all groups by age(OrderBy)");
            Console.WriteLine("order's all employees in group's by surename(OrderBy)");
            IEnumerable<IGrouping<int, Person>> query = Employees.GroupBy(x => x.Age);
            foreach (IGrouping<int, Person> AgeGroup in query.OrderBy(x => x.Key ))
            {
                Console.WriteLine("----------Age:" + AgeGroup.Key + "------------------");
                ViewPersonList(AgeGroup.ToList().OrderBy(x => x.Surname).ToList());
            }
            Console.ReadLine();
        }

        private static void ViewPersonList(List<Person> list)
        {
            foreach (Person Person in list)
            {
                Console.WriteLine(Person.PersonalId+"\t:\t" + Person.Firstname + "\t" + Person.Surname + "\t" + Person.Age);
            }
        }
        private static void ViewPerson(Person singelPerson)
        {
            Console.WriteLine(singelPerson.PersonalId + "\t:\t" + singelPerson.Firstname + "\t" + singelPerson.Surname + "\t" + singelPerson.Age);
        }
    }
}
