﻿namespace System.Web.Mvc {
    public enum TagRenderMode {
        Normal,
        StartTag,
        EndTag,
        SelfClosing
    }
}
