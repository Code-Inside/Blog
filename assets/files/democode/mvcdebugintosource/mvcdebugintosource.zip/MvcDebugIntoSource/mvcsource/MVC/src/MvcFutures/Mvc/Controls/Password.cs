﻿namespace Microsoft.Web.Mvc.Controls {

    public class Password : MvcInputControl {
        public Password() :
            base("password") {
        }
    }
}
