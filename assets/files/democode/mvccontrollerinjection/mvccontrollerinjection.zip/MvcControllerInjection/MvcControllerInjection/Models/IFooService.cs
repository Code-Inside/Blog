﻿namespace MvcControllerInjection.Models
{
    public interface IFooService
    {
        string Bar();
    }
}