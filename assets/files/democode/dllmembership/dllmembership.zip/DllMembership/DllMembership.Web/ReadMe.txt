﻿3 Rollen:
- Administrator
- Benutzer
- Redakteur

2 Benutzer:
- Kennwort ist "Membership2008!"
- Sicherheitsfrage & Antwort ist "Membership"
- Nutzer
  - "Hans" (Benutzer)
  - "Robert" (Administrator)
  - "Max" (Redakteur)