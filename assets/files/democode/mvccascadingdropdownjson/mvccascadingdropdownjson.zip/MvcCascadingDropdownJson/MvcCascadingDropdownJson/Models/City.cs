﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcCascadingDropdownJson.Models
{
    public class City
    {
        public string Name { get; set; }
    }
}
