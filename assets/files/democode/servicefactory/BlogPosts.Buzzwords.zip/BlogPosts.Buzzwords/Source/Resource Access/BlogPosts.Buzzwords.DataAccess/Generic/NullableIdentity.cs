﻿using System;
namespace BlogPosts.Buzzwords.DataAccess
{
    public class NullableIdentity
    {
    }
}
