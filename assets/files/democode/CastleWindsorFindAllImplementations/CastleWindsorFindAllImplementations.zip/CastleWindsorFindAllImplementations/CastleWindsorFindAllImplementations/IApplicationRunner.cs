namespace CastleWindsorFindAllImplementations
{
    public interface IApplicationRunner
    {
        void Run();
    }
}